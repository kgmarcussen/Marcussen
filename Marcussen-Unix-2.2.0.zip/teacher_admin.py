"""Marcussen teacher console."""
from __future__ import annotations

import json
import os
import shutil
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.parse
import urllib.request
import webbrowser
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import license as license_mod

APP_NAME = "Marcussen"
CLIENT_VERSION = "2.2.0"
STORE_PDP = "ms-windows-store://pdp/?productid=XPFFKWDD8XVX6R"
STORE_WEB = "https://apps.microsoft.com/detail/XPFFKWDD8XVX6R"
STUDENT_SETUP_URL = "https://github.com/kgmarcussen/Marcussen/raw/main/Marcussen-Student-Setup.exe"
LIST_URLS = [
    "https://raw.githubusercontent.com/kgmarcussen/Marcussen/main/lists/{name}.txt",
    "https://github.com/kgmarcussen/Marcussen/raw/main/lists/{name}.txt",
    "https://marcussen.42web.io/{name}.txt",
]
SEAT_URL = "https://marcussen.42web.io/license.php"
BUY_URL = "https://marcussen.42web.io/block.html"
FAQ_URL = "https://marcussen.42web.io/faq.html"
PRIVACY_URL = "https://marcussen.42web.io/privacy.html"

BUILTIN = {
    "ai": [("openai.com", "domain"), ("chatgpt.com", "domain"), ("anthropic.com", "domain"),
           ("claude.ai", "domain"), ("gemini.google.com", "host"), ("venice.ai", "domain")],
    "social": [("tiktok.com", "domain"), ("instagram.com", "domain"), ("facebook.com", "domain"),
               ("x.com", "domain"), ("twitter.com", "domain"), ("snapchat.com", "domain"),
               ("reddit.com", "domain"), ("discord.com", "domain")],
    "video": [("youtube.com", "domain"), ("netflix.com", "domain"), ("hulu.com", "domain"),
              ("twitch.tv", "domain"), ("tiktok.com", "domain")],
    "music": [("spotify.com", "domain"), ("soundcloud.com", "domain"), ("music.youtube.com", "host"),
              ("pandora.com", "domain")],
    "games": [("poki.com", "domain"), ("crazygames.com", "domain"), ("roblox.com", "domain"),
              ("miniclip.com", "domain"), ("kongregate.com", "domain"),
              ("steampowered.com", "domain"), ("steamcommunity.com", "domain"),
              ("steamgames.com", "domain"), ("steamusercontent.com", "domain"),
              ("steamstatic.com", "domain"), ("valvesoftware.com", "domain"),
              ("steamchina.com", "domain")],
    "translation": [
        ("translate.google.com", "host"), ("deepl.com", "domain"), ("translate.yandex.com", "host"),
        ("reverso.net", "domain"), ("babelfish.com", "domain"), ("quillbot.com", "domain"),
        ("papago.naver.com", "host"), ("systransoft.com", "domain"), ("linguee.com", "domain"),
        ("cambridge.org", "domain"), ("collinsdictionary.com", "domain"),
    ],
}


TEMPLATES = {k: list(v) for k, v in BUILTIN.items()}


def parse_list_text(text: str) -> list[tuple[str, str]]:
    rows = []
    for line in (text or "").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or line.startswith("<"):
            continue
        parts = line.split()
        if parts[0].lower() in ("domain", "host") and len(parts) >= 2:
            mode, pat = parts[0].lower(), parts[1]
        else:
            mode, pat = "domain", parts[0]
        pat = pat.lower().replace("https://", "").replace("http://", "").split("/")[0].lstrip("*.")
        if pat:
            rows.append((pat, mode))
    return rows


def fetch_remote_lists() -> dict:
    notes = {}
    for name in ("ai", "social", "video", "music", "games", "translation"):
        got = None
        src = ""
        for tmpl in LIST_URLS:
            url = tmpl.format(name=name)
            try:
                req = urllib.request.Request(url, headers={"User-Agent": "MarcussenTeacher/2.0"})
                with urllib.request.urlopen(req, timeout=12) as resp:
                    raw = resp.read().decode("utf-8", "replace")
                rows = parse_list_text(raw)
                if rows:
                    got = rows
                    src = "GitHub" if "github" in url else "website"
                    break
            except Exception:
                continue
        if got:
            TEMPLATES[name] = got
            notes[name] = f"{src}, {len(got)}"
        else:
            notes[name] = "empty or unreadable"
    return notes


def _state_dir() -> Path:
    base = os.environ.get("LOCALAPPDATA") or str(Path.home())
    p = Path(base) / "Marcussen"
    p.mkdir(parents=True, exist_ok=True)
    return p


def load_prefs() -> dict:
    path = _state_dir() / "teacher_config.json"
    data = license_mod.load_state()
    if path.exists():
        try:
            extra = json.loads(path.read_text(encoding="utf-8"))
            data.update(extra)
        except Exception:
            pass
    data.setdefault("port", 8080)
    data.setdefault("rules", [])
    data.setdefault("enabled", False)
    data.setdefault("unlock_password", "")
    data.setdefault("disable_copy", False)
    data.setdefault("machine_off", [])
    data.setdefault("force_google_web", False)
    data.setdefault("disable_incognito", False)
    data.setdefault("custom_rules", [])
    data.setdefault("active_sets", {})
    data.setdefault("policies", {})
    data.setdefault("mode", "blacklist")
    return data


def save_prefs(data: dict) -> None:
    license_mod.save_state(data)
    path = _state_dir() / "teacher_config.json"
    try:
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        pass


class Hub:
    def __init__(self):
        self.lock = threading.Lock()
        self.prefs = load_prefs()
        self.contacts = {}
        self.httpd = None
        self.port = int(self.prefs.get("port") or 8080)

    def status_payload(self, client_ip: str = "") -> dict:
        with self.lock:
            enabled = bool(self.prefs.get("enabled"))
            if not license_mod.can_enable_blocking(self.prefs):
                enabled = False
            if client_ip and client_ip in (self.prefs.get("machine_off") or []):
                enabled = False
            return {
                "enabled": enabled,
                "mode": "blacklist",
                "rules": list(self.prefs.get("rules") or []),
                "blacklist": [r.get("pattern") for r in (self.prefs.get("rules") or []) if isinstance(r, dict)],
                "unlock_password": self.prefs.get("unlock_password") or "",
                "disable_copy": bool(self.prefs.get("disable_copy")),
                "force_google_web": bool((self.prefs.get("policies") or {}).get("force_google_web", self.prefs.get("force_google_web"))),
                "disable_incognito": bool((self.prefs.get("policies") or {}).get("disable_incognito", self.prefs.get("disable_incognito"))),
                "policies": dict(self.prefs.get("policies") or {}),
                "client_version": CLIENT_VERSION,
            }

    def note_contact(self, ip: str, name: str = "", login: str = "", version: str = ""):
        with self.lock:
            old = self.contacts.get(ip) or {}
            self.contacts[ip] = {
                "ip": ip,
                "name": name or old.get("name") or "",
                "login": login or old.get("login") or "",
                "version": version or old.get("version") or "",
                "ts": time.time(),
            }


HUB = Hub()


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def _send(self, obj):
        raw = json.dumps(obj).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        ip = self.client_address[0]
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)
        name = (self.headers.get("X-Computer") or (qs.get("name") or [""])[0] or "").strip()
        login = (self.headers.get("X-Login") or (qs.get("login") or [""])[0] or "").strip()
        version = (self.headers.get("X-Client-Version") or (qs.get("ver") or [""])[0] or "").strip()
        if parsed.path.startswith("/status"):
            HUB.note_contact(ip, name, login, version)
            self._send(HUB.status_payload(ip))
            return
        if parsed.path.startswith("/files/student_client.py") or parsed.path == "/student_client.py":
            src = Path(__file__).resolve().parent / "student_client.py"
            try:
                raw = src.read_bytes()
            except Exception:
                self.send_error(404)
                return
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("X-Client-Version", CLIENT_VERSION)
            self.end_headers()
            self.wfile.write(raw)
            return
        self._send({"app": APP_NAME, "client_version": CLIENT_VERSION})


def start_server(port: int) -> str:
    HUB.port = port
    HUB.httpd = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    threading.Thread(target=HUB.httpd.serve_forever, daemon=True).start()
    ip = "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
    except Exception:
        pass
    return ip


def notify_students():
    now = time.time()
    with HUB.lock:
        items = list(HUB.contacts.items())
    for ip, meta in items:
        if now - meta.get("ts", 0) > 360:
            continue
        try:
            urllib.request.urlopen(f"http://{ip}:8081/reload", timeout=3).read()
        except Exception:
            pass


def push_upgrades() -> tuple[int, list]:
    now = time.time()
    with HUB.lock:
        items = list(HUB.contacts.items())
    ok = 0
    failed = []
    for ip, meta in items:
        if now - meta.get("ts", 0) > 360:
            continue
        name = (meta.get("name") or "").strip() or "name unknown"
        login = (meta.get("login") or "").strip() or "login unknown"
        label = f"{name} ({login}) @ {ip}"
        try:
            urllib.request.urlopen(f"http://{ip}:8081/upgrade", timeout=8).read()
            ok += 1
        except Exception as exc:
            failed.append(f"{label} — {exc}")
    return ok, failed


def local_ip() -> str:
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def teacher_run_command() -> str:
    app = Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Marcussen"
    pyw = app / "python" / "pythonw.exe"
    script = app / "teacher_admin.py"
    if pyw.exists() and script.exists():
        return f'"{pyw}" "{script}"'
    return f'"{sys.executable}" "{Path(__file__).resolve()}"'


def startup_enabled() -> bool:
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run")
        winreg.QueryValueEx(key, "MarcussenTeacher")
        winreg.CloseKey(key)
        return True
    except Exception:
        return False


def set_startup(on: bool) -> None:
    try:
        import winreg
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run")
        if on:
            winreg.SetValueEx(key, "MarcussenTeacher", 0, winreg.REG_SZ, teacher_run_command())
        else:
            try:
                winreg.DeleteValue(key, "MarcussenTeacher")
            except FileNotFoundError:
                pass
        winreg.CloseKey(key)
    except Exception:
        pass


def generate_student_installer(ip: str, port: int, dest: Path) -> str:
    here = Path(__file__).resolve().parent
    staging = Path(tempfile.mkdtemp(prefix="marcussen-client-"))
    try:
        for name in ("student_client.py", "install_student.py"):
            src = here / name
            if src.exists():
                shutil.copy2(src, staging / name)
        py_src = here / "python"
        if py_src.exists():
            zpy = staging / "python.zip"
            with zipfile.ZipFile(zpy, "w", zipfile.ZIP_DEFLATED) as zf:
                for p in py_src.rglob("*"):
                    if p.is_file():
                        zf.write(p, p.relative_to(py_src))
        bat = staging / "install.bat"
        bat.write_text(
            "@echo off\r\n"
            "net session >nul 2>&1\r\n"
            "if %errorlevel% neq 0 (\r\n"
            "  powershell -Command \"Start-Process -FilePath '%~f0' -Verb RunAs\"\r\n"
            "  exit /b\r\n"
            ")\r\n"
            "set DEST=%ProgramFiles%\\Marcussen\r\n"
            "mkdir \"%DEST%\" 2>nul\r\n"
            "if exist \"%~dp0python.zip\" powershell -NoProfile -Command \"Expand-Archive -Force -Path '%~dp0python.zip' -DestinationPath '%DEST%\\python'\"\r\n"
            "if exist \"%~dp0python\\python.exe\" xcopy /E /I /Y \"%~dp0python\" \"%DEST%\\python\" >nul\r\n"
            "copy /Y \"%~dp0student_client.py\" \"%DEST%\\\" >nul\r\n"
            "copy /Y \"%~dp0install_student.py\" \"%DEST%\\\" >nul\r\n"
            "set PY=%DEST%\\python\\python.exe\r\n"
            "if not exist \"%PY%\" set PY=python\r\n"
            "\"%PY%\" \"%DEST%\\install_student.py\" " + ip + " " + str(port) + "\r\n",
            encoding="ascii",
            errors="replace",
        )
        (staging / "teacher.txt").write_text(f"{ip}:{port}\n", encoding="utf-8")
        dest = Path(dest)
        dest.parent.mkdir(parents=True, exist_ok=True)
        iexpress = Path(os.environ.get("WINDIR", r"C:\Windows")) / "System32" / "iexpress.exe"
        if os.name == "nt" and iexpress.exists():
            sed = staging / "client.sed"
            files = [p.name for p in staging.iterdir() if p.is_file() and p.suffix.lower() != ".sed"]
            # IExpress SourceFiles0 entries
            lines = [
                "[Version]",
                "Class=IEXPRESS",
                "SEDVersion=3",
                "[Options]",
                "PackagePurpose=InstallApp",
                "ShowInstallProgramWindow=0",
                "HideExtractAnimation=1",
                "UseLongFileName=1",
                "InsideCompressed=1",
                "CAB_FixedSize=0",
                "CAB_ResvCodeSigning=0",
                "RebootMode=N",
                f"TargetName={dest}",
                "FriendlyName=Marcussen Student",
                "AppLaunched=install.bat",
                "PostInstallCmd=<None>",
                "AdminQuietInstCmd=",
                "UserQuietInstCmd=",
                "SourceFiles=SourceFiles",
                "[Strings]",
            ]
            for i, name in enumerate(files):
                lines.append(f"FILE{i}={name}")
            lines.append("[SourceFiles]")
            lines.append(f"SourceFiles0={staging}\\")
            lines.append("[SourceFiles0]")
            for i, name in enumerate(files):
                lines.append(f"%FILE{i}%=")
            sed.write_text("\r\n".join(lines) + "\r\n", encoding="ascii")
            proc = subprocess.run([str(iexpress), "/N", "/Q", str(sed)], check=False)
            if proc.returncode == 0 and dest.exists():
                return str(dest)
        # Fallback zip next to requested path
        zpath = dest.with_suffix(".zip") if dest.suffix.lower() == ".exe" else dest
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as zf:
            for p in staging.rglob("*"):
                if p.is_file() and p.suffix.lower() != ".sed":
                    zf.write(p, p.relative_to(staging))
        return str(zpath)
    finally:
        shutil.rmtree(staging, ignore_errors=True)


def check_store_upgrade() -> str:
    try:
        req = urllib.request.Request(STORE_WEB, headers={"User-Agent": "MarcussenTeacher/2.0.0"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            html = resp.read().decode("utf-8", "replace")
        low = html.lower()
        if CLIENT_VERSION.lower() in low:
            return f"This console is version {CLIENT_VERSION}. The Store page still lists that version, or the page did not expose a newer one. Opening the Store listing."
        return f"This console is version {CLIENT_VERSION}. Open the Store listing to see if a newer package is published."
    except Exception as exc:
        return f"Could not read the Store page ({exc}). Opening the listing so you can check manually."


def single_instance() -> bool:
    if os.name != "nt":
        return True
    try:
        import ctypes
        kernel32 = ctypes.windll.kernel32
        handle = kernel32.CreateMutexW(None, False, "Global\\MarcussenTeacher")
        last = kernel32.GetLastError()
        return last != 183
    except Exception:
        return True


def run_gui():
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk

    if not single_instance():
        try:
            messagebox.showinfo(APP_NAME, "Marcussen is already running. Restore it from the taskbar.")
        except Exception:
            pass
        return

    prefs = HUB.prefs
    if not license_mod.terms_accepted(prefs):
        terms = tk.Tk()
        terms.title("Marcussen terms of use")
        txt = tk.Text(terms, width=72, height=18, wrap="word")
        txt.insert("1.0",
                   "MARCUSSEN TERMS OF USE\n\n"
                   "This software is provided AS IS, without warranty of any kind. "
                   "Use is at your own risk. You may use it only on computers you are "
                   "authorized to administer. The publisher is not liable for blocked "
                   "sites, lost work, or disrupted lessons. By accepting you agree you "
                   "cannot hold the publisher legally responsible beyond what applicable "
                   "law requires.\n")
        txt.config(state="disabled")
        txt.pack(padx=12, pady=12)

        def accept():
            license_mod.mark_terms_and_trial(prefs)
            terms.destroy()

        def decline():
            terms.destroy()
            sys.exit(0)

        tk.Button(terms, text="I accept", command=accept).pack(side="left", padx=20, pady=8)
        tk.Button(terms, text="Exit", command=decline).pack(side="right", padx=20, pady=8)
        terms.mainloop()

    root = tk.Tk()
    root.title("Marcussen Teacher")
    root.geometry("740x680")
    root.minsize(520, 360)
    icon_ico = Path(__file__).resolve().parent / "icons" / "Marcussen_Main.ico"
    icon_png = Path(__file__).resolve().parent / "icons" / "Marcussen_Main.png"
    try:
        if icon_ico.exists():
            root.iconbitmap(default=str(icon_ico))
    except Exception:
        try:
            if icon_png.exists():
                root._icon_img = tk.PhotoImage(file=str(icon_png))
                root.iconphoto(True, root._icon_img)
        except Exception:
            pass

    canvas = tk.Canvas(root, highlightthickness=0)
    scroll = ttk.Scrollbar(root, orient="vertical", command=canvas.yview)
    inner = ttk.Frame(canvas)
    inner.bind("<Configure>", lambda e: canvas.configure(scrollregion=canvas.bbox("all")))
    canvas.create_window((0, 0), window=inner, anchor="nw")
    canvas.configure(yscrollcommand=scroll.set)
    canvas.pack(side="left", fill="both", expand=True)
    scroll.pack(side="right", fill="y")
    def _wheel(target, event):
        target.yview_scroll(int(-1 * (event.delta / 120)), "units")
        return "break"

    canvas.bind("<MouseWheel>", lambda e: _wheel(canvas, e))
    inner.bind("<MouseWheel>", lambda e: _wheel(canvas, e))

    port_var = tk.StringVar(value=str(prefs.get("port") or 8080))
    pass_var = tk.StringVar(value=prefs.get("unlock_password") or "")
    enabled_var = tk.BooleanVar(value=bool(prefs.get("enabled")))
    copy_var = tk.BooleanVar(value=bool(prefs.get("disable_copy")))
    google_var = tk.BooleanVar(value=bool(prefs.get("force_google_web")))
    incog_var = tk.BooleanVar(value=bool(prefs.get("disable_incognito")))
    addr_var = tk.StringVar(value="")
    contact_var = tk.StringVar(value="No /status requests received yet")
    license_var = tk.StringVar(value="")
    key_var = tk.StringVar()
    display_var = tk.StringVar(value="ip")
    show_net = tk.BooleanVar(value=True)
    show_pw = tk.BooleanVar(value=True)
    show_add = tk.BooleanVar(value=True)
    show_saved = tk.BooleanVar(value=True)
    show_conn = tk.BooleanVar(value=True)

    def refresh_license_label():
        if license_mod.is_licensed(prefs):
            license_var.set("Licensed")
        else:
            license_var.set(f"Trial: {license_mod.trial_days_left(prefs)} day(s) left")

    refresh_license_label()

    menubar = tk.Menu(root)
    filem = tk.Menu(menubar, tearoff=0)
    start_var = tk.BooleanVar(value=startup_enabled())

    def toggle_startup():
        set_startup(bool(start_var.get()))
        messagebox.showinfo(APP_NAME, "Teacher console will open at logon." if start_var.get() else "Startup shortcut removed.")

    filem.add_checkbutton(label="Start teacher console at Windows logon", variable=start_var, command=toggle_startup)
    filem.add_separator()
    filem.add_command(label="Exit", command=root.destroy)
    menubar.add_cascade(label="File", menu=filem)
    helpm = tk.Menu(menubar, tearoff=0)
    helpm.add_command(label="FAQ", command=lambda: webbrowser.open(FAQ_URL))
    helpm.add_command(label="Privacy", command=lambda: webbrowser.open(PRIVACY_URL))
    helpm.add_command(label="Buy a key", command=lambda: webbrowser.open(BUY_URL))
    helpm.add_command(label="Microsoft Store listing", command=lambda: webbrowser.open(STORE_PDP))
    menubar.add_cascade(label="Help", menu=helpm)
    root.config(menu=menubar)

    head = ttk.Frame(inner)
    head.pack(fill="x", padx=12, pady=(12, 4))
    try:
        if icon_png.exists():
            root._logo = tk.PhotoImage(file=str(icon_png)).subsample(4, 4)
            ttk.Label(head, image=root._logo).pack(side="left", padx=(0, 10))
    except Exception:
        pass
    ttk.Label(head, text="Marcussen Teacher", font=("Segoe UI", 16, "bold")).pack(side="left")
    vis = ttk.LabelFrame(inner, text="Show sections")
    vis.pack(fill="x", padx=12, pady=4)
    ttk.Checkbutton(vis, text="Network", variable=show_net).pack(side="left", padx=6)
    ttk.Checkbutton(vis, text="Unlock password", variable=show_pw).pack(side="left")
    ttk.Checkbutton(vis, text="Add rules", variable=show_add).pack(side="left", padx=6)
    ttk.Checkbutton(vis, text="Saved rules", variable=show_saved).pack(side="left")
    ttk.Checkbutton(vis, text="Connected computers", variable=show_conn).pack(side="left", padx=6)
    ttk.Label(inner, textvariable=addr_var).pack(anchor="w", padx=12)
    ttk.Label(inner, textvariable=contact_var, foreground="#0a7").pack(anchor="w", padx=12, pady=(0, 8))
    ttk.Label(inner, textvariable=license_var).pack(anchor="w", padx=12)

    lic_frame = ttk.Frame(inner)
    lic_frame.pack(fill="x", padx=12, pady=6)
    key_entry = ttk.Entry(lic_frame, textvariable=key_var, width=28)
    buy_btn = ttk.Button(lic_frame, text="Buy a key", command=lambda: webbrowser.open(BUY_URL))

    def activate():
        ok, msg = license_mod.activate(prefs, key_var.get())
        messagebox.showinfo(APP_NAME, msg)
        if ok:
            key_entry.pack_forget()
            act_btn.pack_forget()
            buy_btn.pack_forget()
            refresh_license_label()
            save_prefs(prefs)

    act_btn = ttk.Button(lic_frame, text="Activate", command=activate)
    if not license_mod.is_licensed(prefs):
        key_entry.pack(side="left", padx=(0, 6))
        act_btn.pack(side="left", padx=4)
        buy_btn.pack(side="left")

    net = ttk.LabelFrame(inner, text="Network")
    net.pack(fill="x", padx=12, pady=8)
    ttk.Label(net, text="Listen port").pack(side="left", padx=8)
    ttk.Entry(net, textvariable=port_var, width=8).pack(side="left")

    def apply_port():
        try:
            port = int(port_var.get())
            if not 1 <= port <= 65535:
                raise ValueError
        except ValueError:
            messagebox.showerror(APP_NAME, "Enter a port from 1 to 65535.")
            return
        prefs["port"] = port
        save_prefs(prefs)
        messagebox.showinfo(APP_NAME, "Port saved. Restart the console to listen on the new port.")

    ttk.Button(net, text="Apply port", command=apply_port).pack(side="left", padx=8)

    pwf = ttk.LabelFrame(inner, text="Student unlock password")
    pwf.pack(fill="x", padx=12, pady=8)
    ttk.Entry(pwf, textvariable=pass_var, show="*", width=24).pack(side="left", padx=8)

    def set_pw():
        pw = pass_var.get().strip()
        if len(pw) < 4:
            messagebox.showerror(APP_NAME, "Use at least 4 characters.")
            return
        prefs["unlock_password"] = pw
        save_prefs(prefs)
        messagebox.showinfo(APP_NAME, "Password saved. Students pick it up on the next poll.")

    ttk.Button(pwf, text="Set password", command=set_pw).pack(side="left")

    rules_title = ttk.Label(inner, text="Active rules (blocked sites)")
    rules_title.pack(anchor="w", padx=12, pady=(8, 0))
    rules_wrap = ttk.Frame(inner)
    rules_wrap.pack(fill="both", expand=True, padx=12, pady=8)
    rules_scroll = ttk.Scrollbar(rules_wrap, orient="vertical")
    rules_box = tk.Listbox(rules_wrap, height=12, yscrollcommand=rules_scroll.set)
    rules_scroll.config(command=rules_box.yview)
    rules_box.pack(side="left", fill="both", expand=True)
    rules_scroll.pack(side="right", fill="y")
    rules_box.bind("<MouseWheel>", lambda e: _wheel(rules_box, e))

    def redraw_rules():
        rules_box.delete(0, "end")
        for r in prefs.get("rules") or []:
            rules_box.insert("end", f"{r.get('mode','domain')}  {r.get('pattern')}")
        rules_title.config(text="Active rules (blocked sites)")

    GOOGLE_GAMES = [
        ("www.google.com/fbx", "url"), ("google.com/fbx", "url"),
        ("www.google.com/doodles", "url"), ("google.com/doodles", "url"),
        ("www.google.com/logos", "url"), ("google.com/logos", "url"),
        ("www.google.com/logos/fnbx", "url"),
    ]

    def set_patterns():
        if "google_games" not in TEMPLATES:
            TEMPLATES["google_games"] = list(GOOGLE_GAMES)

    set_patterns()

    def rebuild_active_rules():
        sets = prefs.setdefault("active_sets", {})
        out = []
        seen = set()
        def add_one(pat, mode):
            key = (pat, mode)
            if key in seen:
                return
            seen.add(key)
            out.append({"pattern": pat, "mode": mode})
        for name, on in list(sets.items()):
            if not on:
                continue
            if name == "custom":
                for r in prefs.get("custom_rules") or []:
                    add_one(r.get("pattern"), r.get("mode") or "domain")
            else:
                for pat, mode in TEMPLATES.get(name, []):
                    add_one(pat, mode)
        prefs["rules"] = out
        save_prefs(prefs)
        redraw_rules()
        notify_students()

    def add_rule(pattern: str, mode: str):
        pattern = pattern.strip().lower().replace("https://", "").replace("http://", "")
        if mode != "url":
            pattern = pattern.split("/")[0]
        else:
            pattern = pattern.split("?", 1)[0].rstrip("/")
        if pattern.startswith("*."):
            pattern = pattern[2:]
            if mode != "url":
                mode = "domain"
        if not pattern:
            return
        custom = prefs.setdefault("custom_rules", [])
        if not any(r.get("pattern") == pattern and r.get("mode") == mode for r in custom):
            custom.append({"pattern": pattern, "mode": mode})
        prefs.setdefault("active_sets", {})["custom"] = True
        save_prefs(prefs)
        rebuild_active_rules()

    addf = ttk.LabelFrame(inner, text="Add rules")
    addf.pack(fill="x", padx=12, pady=8)
    new_var = tk.StringVar()
    ttk.Entry(addf, textvariable=new_var, width=32).pack(side="left", padx=8)
    ttk.Button(addf, text="This host only", command=lambda: add_rule(new_var.get(), "host")).pack(side="left")
    ttk.Button(addf, text="Entire domain", command=lambda: add_rule(new_var.get(), "domain")).pack(side="left", padx=4)
    ttk.Button(addf, text="This URL / path", command=lambda: add_rule(new_var.get(), "url")).pack(side="left", padx=4)

    cat = ttk.LabelFrame(inner, text="Lists — click on to apply, click again to remove")
    cat.pack(fill="x", padx=12, pady=6)
    set_btns = {}

    def refresh_set_buttons():
        sets = prefs.get("active_sets") or {}
        labels = {
            "ai": "AI", "social": "Social", "video": "Video", "music": "Music",
            "games": "Games", "translation": "Translation", "google_games": "Google Games URLs",
            "custom": "Custom list",
        }
        for name, btn in set_btns.items():
            on = bool(sets.get(name))
            btn.config(text=f"{labels.get(name, name)} ({'ON' if on else 'off'})")

    def toggle_set(name):
        sets = prefs.setdefault("active_sets", {})
        sets[name] = not bool(sets.get(name))
        rebuild_active_rules()
        refresh_set_buttons()

    row = ttk.Frame(cat)
    row.pack(fill="x", padx=6, pady=4)
    for key, label in (
        ("ai", "AI"), ("social", "Social"), ("video", "Video"), ("music", "Music"),
        ("games", "Games"), ("translation", "Translation"), ("google_games", "Google Games URLs"),
        ("custom", "Custom list"),
    ):
        b = ttk.Button(row, text=label, command=lambda n=key: toggle_set(n))
        b.pack(side="left", padx=3)
        set_btns[key] = b
    refresh_set_buttons()

    def update_lists():
        notes = fetch_remote_lists()
        parts = [f"{k} ({v})" for k, v in notes.items()]
        messagebox.showinfo(APP_NAME, "Templates updated:\n" + "\n".join(parts) + "\n\nClick a category button to add them to Active rules.")

    ttk.Button(inner, text="Update lists from website", command=update_lists).pack(anchor="w", padx=12, pady=4)
    threading.Thread(target=fetch_remote_lists, daemon=True).start()

    saved = ttk.LabelFrame(inner, text="Saved rule sets")
    saved.pack(fill="x", padx=12, pady=8)

    def save_rules():
        path = filedialog.asksaveasfilename(
            title="Save current rules",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
            initialdir=str(Path.home() / "Documents" / "MarcussenRules"),
        )
        if not path:
            return
        Path(path).write_text(json.dumps({"rules": prefs.get("rules") or []}, indent=2), encoding="utf-8")
        messagebox.showinfo(APP_NAME, "Rules saved.")

    def load_rules(merge=False):
        path = filedialog.askopenfilename(title="Load saved rules", filetypes=[("JSON", "*.json")])
        if not path:
            return
        try:
            data = json.loads(Path(path).read_text(encoding="utf-8"))
            incoming = data.get("rules") if isinstance(data, dict) else data
            if not merge:
                prefs["rules"] = list(incoming or [])
            else:
                have = {(r.get("pattern"), r.get("mode")) for r in prefs.get("rules") or []}
                for r in incoming or []:
                    key = (r.get("pattern"), r.get("mode"))
                    if key not in have:
                        prefs.setdefault("rules", []).append(r)
            save_prefs(prefs)
            redraw_rules()
            notify_students()
        except Exception as exc:
            messagebox.showerror(APP_NAME, str(exc))

    ttk.Button(saved, text="Save current rules…", command=save_rules).pack(side="left", padx=8, pady=6)
    ttk.Button(saved, text="Load saved rules…", command=lambda: load_rules(False)).pack(side="left", padx=4)
    ttk.Button(saved, text="Add saved rules to list…", command=lambda: load_rules(True)).pack(side="left", padx=4)

    def remove_sel():
        idxs = list(rules_box.curselection())
        rules = prefs.get("rules") or []
        for i in reversed(idxs):
            if 0 <= i < len(rules):
                rules.pop(i)
        save_prefs(prefs)
        redraw_rules()
        notify_students()

    ttk.Button(inner, text="Remove selected", command=remove_sel).pack(anchor="w", padx=12)

    block_state = tk.StringVar()

    def refresh_block_state():
        block_state.set("Blocking ON" if prefs.get("enabled") else "Blocking OFF")

    POLICY_LABELS = [
        ("disable_copy", "Block Ctrl+C/V and clipboard"),
        ("force_google_web", "Force Google Web search"),
        ("disable_incognito", "Disable Incognito / InPrivate"),
        ("lens", "Disable Chrome/Edge Lens overlay"),
        ("share", "Disable search content sharing"),
        ("ai_mode", "Disable AI Mode tab"),
        ("gemini", "Disable Gemini in Chrome"),
        ("genai", "Block generative AI features"),
        ("edge_compose", "Disable Edge Compose"),
        ("edge_copilot", "Disable Edge Copilot page context"),
        ("edge_sidebar", "Disable Edge Copilot sidebar"),
        ("edge_local_ai", "Disable Edge local GenAI model"),
    ]
    pol_vars = {}
    pol = prefs.setdefault("policies", {})
    pol_vars["disable_copy"] = copy_var
    pol_vars["force_google_web"] = google_var
    pol_vars["disable_incognito"] = incog_var
    for key, _lbl in POLICY_LABELS:
        if key not in pol_vars:
            pol_vars[key] = tk.BooleanVar(value=bool(pol.get(key)))

    def persist_options():
        prefs["disable_copy"] = bool(pol_vars["disable_copy"].get())
        prefs["force_google_web"] = bool(pol_vars["force_google_web"].get())
        prefs["disable_incognito"] = bool(pol_vars["disable_incognito"].get())
        prefs["mode"] = "blacklist"
        prefs["policies"] = {k: bool(v.get()) for k, v in pol_vars.items()}
        save_prefs(prefs)
        redraw_rules()
        notify_students()
        try:
            refresh_pol_buttons()
        except NameError:
            pass

    def set_blocking(on: bool):
        if on and not license_mod.can_enable_blocking(prefs):
            prefs["enabled"] = False
            enabled_var.set(False)
            save_prefs(prefs)
            refresh_block_state()
            messagebox.showerror(APP_NAME, "Trial ended. Enter a product ID to enable blocking.")
            return
        prefs["enabled"] = bool(on)
        enabled_var.set(bool(on))
        persist_options()
        refresh_block_state()

    def toggle():
        persist_options()

    ctl = ttk.LabelFrame(inner, text="Blocking")
    ctl.pack(fill="x", padx=12, pady=8)
    ttk.Label(ctl, textvariable=block_state, font=("Segoe UI", 10, "bold")).pack(anchor="w", padx=8, pady=(6, 2))
    rowb = ttk.Frame(ctl)
    rowb.pack(fill="x", padx=8, pady=4)
    ttk.Button(rowb, text="Enable blocking", command=lambda: set_blocking(True)).pack(side="left")
    ttk.Button(rowb, text="Disable blocking", command=lambda: set_blocking(False)).pack(side="left", padx=8)
    refresh_block_state()
    polf = ttk.LabelFrame(inner, text="Registry / browser policies — click on or off")
    polf.pack(fill="x", padx=12, pady=8)
    pol_btns = {}

    def refresh_pol_buttons():
        for key, lbl in POLICY_LABELS:
            on = bool(pol_vars[key].get())
            if key in pol_btns:
                pol_btns[key].config(text=f"{lbl} ({'ON' if on else 'off'})")

    def toggle_pol(key):
        pol_vars[key].set(not bool(pol_vars[key].get()))
        persist_options()

    wrap = ttk.Frame(polf)
    wrap.pack(fill="x", padx=6, pady=4)
    col = 0
    rowi = 0
    for key, lbl in POLICY_LABELS:
        b = ttk.Button(wrap, text=lbl, command=lambda k=key: toggle_pol(k))
        b.grid(row=rowi, column=col, sticky="ew", padx=3, pady=2)
        pol_btns[key] = b
        col += 1
        if col >= 2:
            col = 0
            rowi += 1
    wrap.columnconfigure(0, weight=1)
    wrap.columnconfigure(1, weight=1)
    refresh_pol_buttons()

    def do_upgrade():
        ok, failed = push_upgrades()
        lines = [
            f"Pushed client {CLIENT_VERSION} to {ok} computer(s).",
            f"Failed: {len(failed)}.",
        ]
        if failed:
            lines.append("")
            lines.append("Could not update:")
            lines.extend(failed)
        else:
            lines.append("No failures.")
        lines.append("")
        lines.append("Each student must already be running a client that accepts /upgrade.")
        messagebox.showinfo(APP_NAME, "\n".join(lines))

    ttk.Button(inner, text="Force upgrade student clients to this console version", command=do_upgrade).pack(anchor="w", padx=12, pady=6)

    def download_student():
        webbrowser.open(STUDENT_SETUP_URL)

    def store_upgrade():
        msg = check_store_upgrade()
        webbrowser.open(STORE_PDP)
        webbrowser.open(STORE_WEB)
        messagebox.showinfo(APP_NAME, msg)

    ttk.Button(inner, text="Download student installer (GitHub)", command=download_student).pack(anchor="w", padx=12, pady=4)
    ttk.Button(inner, text="Check for upgrade (Microsoft Store)", command=store_upgrade).pack(anchor="w", padx=12, pady=4)

    conn = ttk.LabelFrame(inner, text="Connected computers — check to apply blocking")
    conn.pack(fill="both", padx=12, pady=8)
    ttk.Radiobutton(conn, text="IP address", variable=display_var, value="ip").pack(anchor="w")
    ttk.Radiobutton(conn, text="Computer name", variable=display_var, value="name").pack(anchor="w")
    ttk.Radiobutton(conn, text="Login name", variable=display_var, value="login").pack(anchor="w")
    conn_canvas = tk.Canvas(conn, height=160, highlightthickness=0)
    conn_scroll = ttk.Scrollbar(conn, orient="vertical", command=conn_canvas.yview)
    conn_inner = ttk.Frame(conn_canvas)
    conn_inner.bind("<Configure>", lambda e: conn_canvas.configure(scrollregion=conn_canvas.bbox("all")))
    conn_canvas.create_window((0, 0), window=conn_inner, anchor="nw")
    conn_canvas.configure(yscrollcommand=conn_scroll.set)
    conn_canvas.pack(side="left", fill="both", expand=True, padx=8, pady=8)
    conn_canvas.bind("<MouseWheel>", lambda e: _wheel(conn_canvas, e))
    conn_inner.bind("<MouseWheel>", lambda e: _wheel(conn_canvas, e))
    conn_scroll.pack(side="right", fill="y")
    machine_vars = {}

    def set_machine(ip: str, on: bool):
        off = list(prefs.get("machine_off") or [])
        if on and ip in off:
            off.remove(ip)
        if not on and ip not in off:
            off.append(ip)
        prefs["machine_off"] = off
        save_prefs(prefs)
        notify_students()

    def check_all(on: bool):
        now = time.time()
        with HUB.lock:
            ips = [c["ip"] for c in HUB.contacts.values() if now - c.get("ts", 0) < 360]
        prefs["machine_off"] = [] if on else list(ips)
        save_prefs(prefs)
        for ip, var in machine_vars.items():
            var.set(on)
        notify_students()

    btns = ttk.Frame(conn)
    btns.pack(fill="x", padx=8)
    ttk.Button(btns, text="Check all", command=lambda: check_all(True)).pack(side="left")
    ttk.Button(btns, text="Uncheck all", command=lambda: check_all(False)).pack(side="left", padx=6)

    def tick():
        now = time.time()
        with HUB.lock:
            items = [c for c in HUB.contacts.values() if now - c.get("ts", 0) < 360]
        if not items:
            contact_var.set("No /status requests received yet" if not HUB.contacts else "No recent student contacts")
        else:
            labels = []
            for c in items:
                kind = display_var.get()
                if kind == "name":
                    labels.append(c.get("name") or c["ip"])
                elif kind == "login":
                    labels.append(c.get("login") or "login not reported")
                else:
                    labels.append(c["ip"])
            contact_var.set(f"Last /status hit {int(now - max(c['ts'] for c in items))}s ago. Recent contacts ({len(items)}): " + ", ".join(labels[:8]))
        off = set(prefs.get("machine_off") or [])
        live = {c["ip"] for c in items}
        for child in conn_inner.winfo_children():
            child.destroy()
        machine_vars.clear()
        for c in sorted(items, key=lambda x: (x.get("name") or x["ip"]).lower()):
            ip = c["ip"]
            kind = display_var.get()
            if kind == "name":
                label = c.get("name") or ip
            elif kind == "login":
                label = c.get("login") or "login not reported"
            else:
                label = ip
            extra = f"{c.get('name') or '-'} | {c.get('login') or '-'} | {ip}"
            var = tk.BooleanVar(value=ip not in off)
            machine_vars[ip] = var
            ttk.Checkbutton(
                conn_inner,
                text=f"{label}   ({extra})",
                variable=var,
                command=lambda i=ip, v=var: set_machine(i, v.get()),
            ).pack(anchor="w")
        root.after(3000, tick)

    def apply_vis(*_):
        for fr in (net, pwf, addf, saved, conn):
            try:
                fr.pack_forget()
            except Exception:
                pass
        if show_net.get():
            net.pack(fill="x", padx=12, pady=8)
        if show_pw.get():
            pwf.pack(fill="x", padx=12, pady=8)
        if show_add.get():
            addf.pack(fill="x", padx=12, pady=8)
        if show_saved.get():
            saved.pack(fill="x", padx=12, pady=8)
        if show_conn.get():
            conn.pack(fill="both", padx=12, pady=8)

    for var in (show_net, show_pw, show_add, show_saved, show_conn):
        var.trace_add("write", apply_vis)

    try:
        ip = start_server(int(port_var.get()))
        addr_var.set(f"http://{ip}:{port_var.get()}")
    except Exception as exc:
        addr_var.set(f"Could not bind port: {exc}")

    redraw_rules()
    tick()
    root.mainloop()


if __name__ == "__main__":
    run_gui()
