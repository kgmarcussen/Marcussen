import json
import os
import subprocess
import sys
from pathlib import Path


def app_dir() -> Path:
    if sys.platform == "darwin":
        return Path("/Library/Application Support/Marcussen")
    if os.name == "nt":
        return Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Marcussen"
    return Path("/opt/marcussen")


def install_windows(app: Path, ip: str, port: int) -> None:
    py = app / "python" / "python.exe"
    pyw = app / "python" / "pythonw.exe"
    if not py.exists():
        py = Path(sys.executable)
    if not pyw.exists():
        pyw = py
    try:
        import winreg
        key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Marcussen")
        winreg.SetValueEx(key, "TeacherIP", 0, winreg.REG_SZ, ip)
        winreg.SetValueEx(key, "Port", 0, winreg.REG_DWORD, port)
        winreg.CloseKey(key)
    except Exception:
        pass
    tr = r'"{}" "{}" --daemon'.format(py, app / "student_client.py")
    subprocess.run(
        ["schtasks", "/Create", "/TN", "Marcussen", "/TR", tr, "/SC", "ONSTART",
         "/RU", "SYSTEM", "/RL", "HIGHEST", "/F"],
        check=False,
    )
    subprocess.run(["schtasks", "/Run", "/TN", "Marcussen"], check=False)
    clip = r'"{}" "{}" --clip'.format(pyw, app / "student_client.py")
    subprocess.run(
        ["schtasks", "/Create", "/TN", "MarcussenClip", "/TR", clip, "/SC", "ONLOGON",
         "/IT", "/RL", "LIMITED", "/F"],
        check=False,
    )
    subprocess.run(["schtasks", "/Run", "/TN", "MarcussenClip"], check=False)


def install_macos(app: Path) -> None:
    plist = Path("/Library/LaunchDaemons/io.marcussen.client.plist")
    py = sys.executable
    body = f"""<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>io.marcussen.client</string>
  <key>ProgramArguments</key>
  <array>
    <string>{py}</string>
    <string>{app / "student_client.py"}</string>
    <string>--daemon</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
</dict>
</plist>
"""
    plist.write_text(body, encoding="utf-8")
    subprocess.run(["launchctl", "bootout", "system/io.marcussen.client"], check=False)
    subprocess.run(["launchctl", "bootstrap", "system", str(plist)], check=False)
    subprocess.run(["launchctl", "kickstart", "-k", "system/io.marcussen.client"], check=False)


def install_linux(app: Path) -> None:
    unit = Path("/etc/systemd/system/marcussen.service")
    py = sys.executable
    unit.write_text(
        "[Unit]\nDescription=Marcussen student client\nAfter=network-online.target\n\n"
        "[Service]\nType=simple\n"
        f"ExecStart={py} {app / 'student_client.py'} --daemon\n"
        "Restart=always\nRestartSec=5\n\n"
        "[Install]\nWantedBy=multi-user.target\n",
        encoding="utf-8",
    )
    subprocess.run(["systemctl", "daemon-reload"], check=False)
    subprocess.run(["systemctl", "enable", "--now", "marcussen.service"], check=False)


def main():
    ip = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
    port = int(sys.argv[2]) if len(sys.argv) > 2 else 8080
    app = app_dir()
    app.mkdir(parents=True, exist_ok=True)
    here = Path(__file__).resolve().parent
    for name in ("student_client.py", "install_student.py"):
        src = here / name
        dest = app / name
        if src.exists() and src.resolve() != dest.resolve():
            dest.write_bytes(src.read_bytes())
    (app / "config.json").write_text(
        json.dumps({"teacher_ip": ip, "port": port, "poll_seconds": 120}, indent=2),
        encoding="utf-8",
    )
    if os.name == "nt":
        install_windows(app, ip, port)
    elif sys.platform == "darwin":
        install_macos(app)
    else:
        install_linux(app)
    print(f"Marcussen student installed for {ip}:{port} in {app}")


if __name__ == "__main__":
    main()
