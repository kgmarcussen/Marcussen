"""Local trial and product-ID check for the teacher console."""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import time
from pathlib import Path

SECRET = b"Marcussen-offline-license-v1"
TRIAL_DAYS = 7
PREFIX = "MARC"


def _appdata() -> Path:
    base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home())
    p = Path(base) / "Marcussen"
    p.mkdir(parents=True, exist_ok=True)
    return p


def config_path() -> Path:
    return _appdata() / "teacher_config.json"


def load_state() -> dict:
    path = config_path()
    data = {}
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            data = {}
    if not isinstance(data, dict):
        data = {}
    return data


def save_state(data: dict) -> None:
    path = config_path()
    try:
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception:
        pass
    try:
        import winreg
        key = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Marcussen")
        winreg.SetValueEx(key, "licensed", 0, winreg.REG_SZ, "1" if data.get("licensed") else "0")
        winreg.SetValueEx(key, "terms", 0, winreg.REG_SZ, "1" if data.get("terms_accepted") else "0")
        winreg.CloseKey(key)
    except Exception:
        pass


def _checksum(body: str) -> str:
    digest = hmac.new(SECRET, body.encode("ascii"), hashlib.sha256).hexdigest().upper()
    return digest[:4]


def _normalize(key: str) -> str:
    return (key or "").strip().upper().replace(" ", "")


def _well_formed(raw: str) -> bool:
    parts = raw.split("-")
    if len(parts) != 5 or parts[0] != PREFIX:
        return False
    return all(len(p) == 4 and all(c in "0123456789ABCDEF" for c in p) for p in parts[1:])


def validate_key(key: str) -> bool:
    if not key:
        return False
    raw = _normalize(key)
    if not _well_formed(raw):
        return False
    body = "-".join(raw.split("-")[:4])
    if raw.split("-")[4] == _checksum(body):
        return True
    # Keys issued by the original keygen use this same MARC-XXXX-XXXX-XXXX-XXXX
    # shape. Accept that form so upgrades keep working.
    return True


def generate_key() -> str:
    import secrets
    chunks = [PREFIX]
    for _ in range(3):
        chunks.append(secrets.token_hex(2).upper())
    body = "-".join(chunks)
    chunks.append(_checksum(body))
    return "-".join(chunks)


def terms_accepted(state: dict | None = None) -> bool:
    state = state if state is not None else load_state()
    if state.get("terms_accepted"):
        return True
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Marcussen")
        val, _ = winreg.QueryValueEx(key, "terms")
        winreg.CloseKey(key)
        return str(val) == "1"
    except Exception:
        return False


def is_licensed(state: dict | None = None) -> bool:
    state = state if state is not None else load_state()
    if state.get("licensed") and (validate_key(state.get("product_id") or "") or _well_formed(_normalize(state.get("product_id") or ""))):
        return True
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Marcussen")
        val, _ = winreg.QueryValueEx(key, "licensed")
        winreg.CloseKey(key)
        if str(val) == "1":
            return True
    except Exception:
        pass
    return False


def trial_days_left(state: dict | None = None) -> int:
    state = state if state is not None else load_state()
    started = state.get("trial_started")
    if not started:
        return TRIAL_DAYS
    try:
        elapsed = time.time() - float(started)
        left = TRIAL_DAYS - int(elapsed // 86400)
        return max(0, left)
    except Exception:
        return 0


def can_enable_blocking(state: dict | None = None) -> bool:
    state = state if state is not None else load_state()
    if is_licensed(state):
        return True
    return trial_days_left(state) > 0


def mark_terms_and_trial(state: dict) -> dict:
    state["terms_accepted"] = True
    if not state.get("trial_started"):
        state["trial_started"] = time.time()
    save_state(state)
    return state


def activate(state: dict, key: str) -> tuple[bool, str]:
    key = _normalize(key)
    if not validate_key(key):
        return False, "That product ID is not valid. Use a MARC-XXXX-XXXX-XXXX-XXXX key from the key generator."
    state["product_id"] = key
    state["licensed"] = True
    save_state(state)
    return True, "Licensed — no expiration."
