#!/bin/sh
# Marcussen student client for macOS and Linux.
# Usage: sudo ./install_unix.sh TEACHER_IP [PORT]
set -e
IP="${1:-}"
PORT="${2:-8080}"
if [ -z "$IP" ]; then
  echo "Usage: sudo $0 TEACHER_IP [PORT]"
  exit 1
fi
if [ "$(id -u)" -ne 0 ]; then
  echo "Run as root: sudo $0 $IP $PORT"
  exit 1
fi
PY="$(command -v python3 || true)"
if [ -z "$PY" ]; then
  echo "python3 is required"
  exit 1
fi
DIR="$(CDPATH= cd -- "$(dirname "$0")" && pwd)"
"$PY" "$DIR/install_student.py" "$IP" "$PORT"
echo "Done. Fully quit browsers on this computer, then open them again."
echo "macOS: launchctl print system/io.marcussen.client"
echo "Linux: systemctl status marcussen.service"
