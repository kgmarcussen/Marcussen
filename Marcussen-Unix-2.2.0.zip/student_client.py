"""Marcussen student client: poll teacher, apply hosts and browser policy."""
from __future__ import annotations

import json
import os
import re
import socket
import subprocess
import sys
import threading
import time
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path

def _paths():
    if sys.platform == "darwin":
        app = Path("/Library/Application Support/Marcussen")
        log = Path("/Library/Logs/Marcussen/marcussen.log")
        hosts = Path("/etc/hosts")
    elif os.name == "nt":
        app = Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")) / "Marcussen"
        log = Path(os.environ.get("PROGRAMDATA", r"C:\ProgramData")) / "Marcussen" / "marcussen.log"
        hosts = Path(os.environ.get("SystemRoot", r"C:\Windows")) / "System32" / "drivers" / "etc" / "hosts"
    else:
        app = Path("/opt/marcussen")
        log = Path("/var/log/marcussen.log")
        hosts = Path("/etc/hosts")
    return app, app / "config.json", hosts, log


APP_DIR, CONFIG_FILE, HOSTS, LOG = _paths()
MARKER = "# marcussen-blocker"
RELOAD_PORT = 8081
CLIENT_VERSION = "2.2.0"
SEARCH_URL = "{google:baseURL}search?udm=14&q={searchTerms}"
SUGGEST_URL = "https://www.google.com/complete/search?client=chrome&q={searchTerms}"


def log(msg: str) -> None:
    try:
        LOG.parent.mkdir(parents=True, exist_ok=True)
        with LOG.open("a", encoding="utf-8") as fh:
            fh.write(time.strftime("%Y-%m-%d %H:%M:%S ") + msg + "\n")
    except Exception:
        pass


def _hidden_kwargs() -> dict:
    kw = {}
    if os.name == "nt":
        kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = 0
        kw["startupinfo"] = si
    return kw


def computer_name() -> str:
    return os.environ.get("COMPUTERNAME") or socket.gethostname() or ""


def login_name() -> str:
    if os.name != "nt":
        return os.environ.get("USER") or os.environ.get("LOGNAME") or ""
    user = os.environ.get("USERNAME") or ""
    if user and user.lower() not in ("system", "local service", "network service"):
        return user
    try:
        out = subprocess.check_output(["query", "user"], text=True, timeout=4, **_hidden_kwargs())
    except Exception:
        try:
            out = subprocess.check_output(["quser"], text=True, timeout=4, **_hidden_kwargs())
        except Exception:
            return ""
    for line in out.splitlines():
        if "Active" in line or "actif" in line.lower() or ">" in line[:2]:
            parts = line.replace(">", " ").split()
            if parts:
                return parts[0]
    for line in out.splitlines()[1:]:
        parts = line.replace(">", " ").split()
        if parts:
            return parts[0]
    return ""


def load_config() -> dict:
    cfg = {"teacher_ip": "127.0.0.1", "port": 8080, "poll_seconds": 120}
    try:
        import winreg
        key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Marcussen")
        ip, _ = winreg.QueryValueEx(key, "TeacherIP")
        port, _ = winreg.QueryValueEx(key, "Port")
        winreg.CloseKey(key)
        if ip:
            cfg["teacher_ip"] = str(ip)
        if port:
            cfg["port"] = int(port)
    except Exception:
        pass
    if CONFIG_FILE.exists():
        try:
            disk = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            if not cfg.get("teacher_ip") or cfg["teacher_ip"] == "127.0.0.1":
                cfg["teacher_ip"] = disk.get("teacher_ip") or cfg["teacher_ip"]
            if disk.get("port"):
                cfg["port"] = int(disk.get("port") or cfg["port"])
            cfg["poll_seconds"] = int(disk.get("poll_seconds") or 120)
        except Exception:
            pass
    return cfg


def fetch_status(cfg: dict) -> dict | None:
    qs = urllib.parse.urlencode({
        "name": computer_name(),
        "login": login_name(),
        "ver": CLIENT_VERSION,
    })
    url = f"http://{cfg['teacher_ip']}:{int(cfg['port'])}/status?{qs}"
    try:
        req = urllib.request.Request(
            url,
            headers={
                "User-Agent": f"MarcussenStudent/{CLIENT_VERSION}",
                "X-Computer": computer_name(),
                "X-Login": login_name(),
                "X-Client-Version": CLIENT_VERSION,
            },
        )
        with urllib.request.urlopen(req, timeout=8) as resp:
            return json.loads(resp.read().decode("utf-8", "replace"))
    except Exception as exc:
        log(f"status failed {url} {exc}")
        return None


def _rule_hosts(rules: list) -> list:
    names = []
    for rule in rules or []:
        if isinstance(rule, dict) and (rule.get("mode") or "") == "url":
            continue
        pat = (rule.get("pattern") if isinstance(rule, dict) else str(rule)).strip().lower()
        pat = pat.replace("*.", "").split("/")[0]
        if not pat:
            continue
        names.append(pat)
        if not pat.startswith("www."):
            names.append("www." + pat)
    return list(dict.fromkeys(names))


def _rule_url_patterns(rules: list) -> list:
    out = []
    for rule in rules or []:
        if not isinstance(rule, dict):
            continue
        pat = (rule.get("pattern") or "").strip().lower()
        if not pat:
            continue
        if (rule.get("mode") or "") == "url":
            pat = pat.replace("https://", "").replace("http://", "").split("?", 1)[0]
            if "*" not in pat:
                pat = pat.rstrip("/") + "*"
            out.append(pat)
            out.append("https://" + pat)
            out.append("http://" + pat)
            if not pat.startswith("www.") and "/" in pat:
                host, rest = pat.split("/", 1)
                out.append("www." + host + "/" + rest)
                out.append("https://www." + host + "/" + rest)
        else:
            host = pat.replace("*.", "").split("/")[0]
            if host:
                out.append(host)
                out.append("*." + host)
    return list(dict.fromkeys(out))


def apply_hosts(enabled: bool, rules: list, mode: str = "blacklist") -> None:
    names = _rule_hosts(rules) if enabled and mode != "whitelist" else []
    try:
        text = HOSTS.read_text(encoding="utf-8", errors="replace") if HOSTS.exists() else ""
    except Exception:
        text = ""
    kept = [ln for ln in text.splitlines() if MARKER not in ln]
    if names:
        kept.append("")
        for n in names:
            kept.append(f"127.0.0.1 {n} {MARKER}")
            kept.append(f"::1 {n} {MARKER}")
    try:
        HOSTS.write_text("\n".join(kept) + "\n", encoding="utf-8")
        log(f"hosts updated enabled={enabled} count={len(names)}")
    except Exception as exc:
        log(f"hosts write failed {exc}")
        return
    try:
        subprocess.run(["ipconfig", "/flushdns"], check=False, **_hidden_kwargs())
    except Exception:
        pass


def _set_browser_policies(hive_path: str, force_google: bool, disable_incog: bool, incog_name: str, policies=None) -> None:
    if os.name != "nt":
        return
    import winreg
    try:
        key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, hive_path)
    except Exception as exc:
        log(f"policy key {hive_path} {exc}")
        return
    try:
        if force_google:
            winreg.SetValueEx(key, "DefaultSearchProviderEnabled", 0, winreg.REG_DWORD, 1)
            winreg.SetValueEx(key, "DefaultSearchProviderName", 0, winreg.REG_SZ, "Google")
            winreg.SetValueEx(key, "DefaultSearchProviderKeyword", 0, winreg.REG_SZ, "google.com")
            winreg.SetValueEx(key, "DefaultSearchProviderSearchURL", 0, winreg.REG_SZ, SEARCH_URL)
            winreg.SetValueEx(key, "DefaultSearchProviderSuggestURL", 0, winreg.REG_SZ, SUGGEST_URL)
        else:
            for name in (
                "DefaultSearchProviderEnabled",
                "DefaultSearchProviderName",
                "DefaultSearchProviderKeyword",
                "DefaultSearchProviderSearchURL",
                "DefaultSearchProviderSuggestURL",
            ):
                try:
                    winreg.DeleteValue(key, name)
                except FileNotFoundError:
                    pass
        if disable_incog:
            winreg.SetValueEx(key, incog_name, 0, winreg.REG_DWORD, 1)
        else:
            try:
                winreg.DeleteValue(key, incog_name)
            except FileNotFoundError:
                pass
        policies = policies or {}
        tail = hive_path.rstrip("\\")
        chrome_like = tail.endswith(r"Google\Chrome") or tail.endswith(r"Microsoft\Edge") or tail.endswith(r"\Opera") or tail.endswith(r"Opera GX")

        def apply_dword(name, on, on_val):
            if on:
                winreg.SetValueEx(key, name, 0, winreg.REG_DWORD, int(on_val))
            else:
                try:
                    winreg.DeleteValue(key, name)
                except FileNotFoundError:
                    pass

        if chrome_like:
            apply_dword("LensOverlaySettings", policies.get("lens"), 1)
            apply_dword("SearchContentSharingSettings", policies.get("share"), 1)
            apply_dword("AIModeSettings", policies.get("ai_mode"), 1)
            apply_dword("GeminiSettings", policies.get("gemini"), 1)
            apply_dword("GenAiDefaultSettings", policies.get("genai"), 2)
        if hive_path.rstrip("\\").endswith(r"Microsoft\Edge"):
            apply_dword("ComposeInlineEnabled", policies.get("edge_compose"), 0)
            apply_dword("CopilotPageContext", policies.get("edge_copilot"), 0)
            apply_dword("HubsSidebarEnabled", policies.get("edge_sidebar"), 0)
            apply_dword("GenAILocalFoundationalModelSettings", policies.get("edge_local_ai"), 1)
    finally:
        winreg.CloseKey(key)


def _clear_list_key(hive: str, sub: str) -> None:
    import winreg
    try:
        winreg.DeleteKey(winreg.HKEY_LOCAL_MACHINE, hive + "\\" + sub)
    except FileNotFoundError:
        pass
    except Exception:
        try:
            key = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, hive + "\\" + sub, 0, winreg.KEY_ALL_ACCESS)
            i = 0
            while True:
                try:
                    name, _, _ = winreg.EnumValue(key, 0)
                    winreg.DeleteValue(key, name)
                except OSError:
                    break
                i += 1
            winreg.CloseKey(key)
        except Exception:
            pass


def _write_list_key(hive: str, sub: str, values: list[str]) -> None:
    import winreg
    _clear_list_key(hive, sub)
    if not values:
        return
    key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, hive + "\\" + sub)
    for i, val in enumerate(values, start=1):
        winreg.SetValueEx(key, str(i), 0, winreg.REG_SZ, val)
    winreg.CloseKey(key)


def _firefox_dirs() -> list:
    out = []
    if os.name == "nt":
        roots = [
            Path(os.environ.get("PROGRAMFILES", r"C:\Program Files")),
            Path(os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)")),
        ]
        names = ("Mozilla Firefox", "Firefox", "Firefox Developer Edition", "Firefox Nightly")
        for root in roots:
            for name in names:
                d = root / name
                if d.exists():
                    out.append(d)
    elif sys.platform == "darwin":
        for d in (Path("/Applications/Firefox.app/Contents/Resources"), Path("/Applications/Firefox Developer Edition.app/Contents/Resources")):
            if d.exists():
                out.append(d)
    else:
        for d in (
            Path("/usr/lib/firefox"),
            Path("/usr/lib64/firefox"),
            Path("/usr/lib/firefox-esr"),
            Path("/etc/firefox"),
        ):
            if d.exists() or d.parent.exists():
                out.append(d)
    return out


def chromium_policy_files() -> list:
    if sys.platform == "darwin":
        return [
            Path("/Library/Google/Chrome/policies/managed/marcussen.json"),
            Path("/Library/Application Support/Google/Chrome/policies/managed/marcussen.json"),
            Path("/Library/Application Support/Microsoft Edge/policies/managed/marcussen.json"),
            Path("/Library/Application Support/com.operasoftware.Opera/policies/managed/marcussen.json"),
        ]
    if os.name != "nt":
        return [
            Path("/etc/opt/chrome/policies/managed/marcussen.json"),
            Path("/etc/chromium/policies/managed/marcussen.json"),
            Path("/etc/opt/edge/policies/managed/marcussen.json"),
            Path("/etc/opera/policies/managed/marcussen.json"),
        ]
    return []


def write_chromium_json(data: dict) -> None:
    enabled = bool(data.get("enabled"))
    pol = data.get("policies") or {}
    patterns = _rule_url_patterns(data.get("rules") or [])
    body = {}
    if enabled:
        body["URLBlocklist"] = patterns
        if pol.get("force_google_web", data.get("force_google_web")):
            body["DefaultSearchProviderEnabled"] = True
            body["DefaultSearchProviderName"] = "Google"
            body["DefaultSearchProviderSearchURL"] = SEARCH_URL
        if pol.get("disable_incognito", data.get("disable_incognito")):
            body["IncognitoModeAvailability"] = 1
        if pol.get("lens"):
            body["LensOverlaySettings"] = 1
        if pol.get("share"):
            body["SearchContentSharingSettings"] = 1
        if pol.get("ai_mode"):
            body["AIModeSettings"] = 1
        if pol.get("gemini"):
            body["GeminiSettings"] = 1
        if pol.get("genai"):
            body["GenAiDefaultSettings"] = 2
    raw = json.dumps(body, indent=2)
    for path in chromium_policy_files():
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(raw, encoding="utf-8")
        except Exception as exc:
            log(f"chromium json {path} {exc}")


def apply_firefox_filter(enabled: bool, mode: str, hosts: list, patterns: list) -> None:
    blocks = []
    allows = []
    if enabled and mode == "whitelist":
        blocks = ["<all_urls>"]
        allows = [f"*://{h}/*" for h in hosts] + [f"*://*.{h}/*" for h in hosts]
    elif enabled:
        for p in patterns:
            p = p.replace("https://", "").replace("http://", "")
            if "/" in p:
                blocks.append("*://" + p if not p.startswith("*") else p)
            else:
                host = p.lstrip("*.")
                blocks.append(f"*://{host}/*")
                blocks.append(f"*://*.{host}/*")
    payload = {"policies": {"WebsiteFilter": {"Block": list(dict.fromkeys(blocks)), "Exceptions": list(dict.fromkeys(allows))}}}
    if not enabled:
        payload = {"policies": {"WebsiteFilter": {"Block": [], "Exceptions": []}}}
    raw = json.dumps(payload, indent=2)
    for d in _firefox_dirs():
        try:
            dist = d / "distribution"
            dist.mkdir(parents=True, exist_ok=True)
            (dist / "policies.json").write_text(raw, encoding="utf-8")
            log(f"firefox policies {d}")
        except Exception as exc:
            log(f"firefox policies {d} {exc}")


def apply_firefox_prefs(disable_incog: bool, force_google: bool) -> None:
    if os.name != "nt":
        return
    import winreg
    try:
        key = winreg.CreateKey(winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Policies\Mozilla\Firefox")
        if disable_incog:
            winreg.SetValueEx(key, "DisablePrivateBrowsing", 0, winreg.REG_DWORD, 1)
        else:
            try:
                winreg.DeleteValue(key, "DisablePrivateBrowsing")
            except FileNotFoundError:
                pass
        winreg.CloseKey(key)
    except Exception as exc:
        log(f"firefox prefs {exc}")
    if force_google:
        extra = {
            "SearchEngines": {
                "Default": "Google",
                "PreventInstalls": False,
            }
        }
        for d in _firefox_dirs():
            path = d / "distribution" / "policies.json"
            try:
                data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {"policies": {}}
                data.setdefault("policies", {}).update(extra)
                if disable_incog:
                    data["policies"]["DisablePrivateBrowsing"] = True
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(json.dumps(data, indent=2), encoding="utf-8")
            except Exception as exc:
                log(f"firefox merge {exc}")


def apply_url_filter(data: dict) -> None:
    if os.name != "nt":
        return
    enabled = bool(data.get("enabled"))
    mode = data.get("mode") or "blacklist"
    hosts = _rule_hosts(data.get("rules") or [])
    patterns = _rule_url_patterns(data.get("rules") or [])
    chromium_hives = (
        r"SOFTWARE\Policies\Google\Chrome",
        r"SOFTWARE\Policies\Microsoft\Edge",
        r"SOFTWARE\Policies\Opera Software\Opera",
        r"SOFTWARE\Policies\Opera Software\Opera GX",
        r"SOFTWARE\Policies\BraveSoftware\Brave",
    )
    if os.name != "nt":
        chromium_hives = ()
    for hive in chromium_hives:
        if not enabled:
            _clear_list_key(hive, "URLBlocklist")
            _clear_list_key(hive, "URLAllowlist")
            continue
        if mode == "whitelist":
            _write_list_key(hive, "URLBlocklist", ["*"])
            allow = list(hosts)
            allow.extend(["https://" + h + "/*" for h in hosts])
            _write_list_key(hive, "URLAllowlist", allow or ["about:blank"])
        else:
            _write_list_key(hive, "URLBlocklist", patterns)
            _clear_list_key(hive, "URLAllowlist")
    apply_firefox_filter(enabled, mode, hosts, patterns)
    log(f"url filter mode={mode} enabled={enabled} patterns={len(patterns)}")


def apply_browser_policy(data: dict) -> None:
    pol = data.get("policies") or {}
    force = bool(pol.get("force_google_web", data.get("force_google_web")))
    incog = bool(pol.get("disable_incognito", data.get("disable_incognito")))
    _set_browser_policies(r"SOFTWARE\Policies\Google\Chrome", force, incog, "IncognitoModeAvailability", pol)
    _set_browser_policies(r"SOFTWARE\Policies\Microsoft\Edge", force, incog, "InPrivateModeAvailability", pol)
    _set_browser_policies(r"SOFTWARE\Policies\Opera Software\Opera", force, incog, "IncognitoModeAvailability", pol)
    _set_browser_policies(r"SOFTWARE\Policies\Opera Software\Opera GX", force, incog, "IncognitoModeAvailability", pol)
    apply_firefox_prefs(incog, force)
    write_chromium_json(data)
    apply_url_filter(data)
    log(f"browser policy google={force} incognito_off={incog} keys={list(pol)}")


def _set_dword(root, path: str, name: str, value: int) -> None:
    import winreg
    key = winreg.CreateKey(root, path)
    winreg.SetValueEx(key, name, 0, winreg.REG_DWORD, int(value))
    winreg.CloseKey(key)


def apply_clipboard_reg(lock_on: bool) -> None:
    """lock_on True -> values 0; unlocked -> values 1."""
    if os.name != "nt":
        return
    import winreg
    val = 0 if lock_on else 1
    targets = [
        (winreg.HKEY_CURRENT_USER, r"Control Panel\Keyboard", "Print Screen Key for Snipping Enabled"),
        (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Clipboard", "EnableClipboardHistory"),
    ]
    try:
        i = 0
        while True:
            sid = winreg.EnumKey(winreg.HKEY_USERS, i)
            i += 1
            if sid.startswith("S-1-5-21-") and "_Classes" not in sid:
                targets.append((winreg.HKEY_USERS, sid + r"\Control Panel\Keyboard", "Print Screen Key for Snipping Enabled"))
                targets.append((winreg.HKEY_USERS, sid + r"\Software\Microsoft\Clipboard", "EnableClipboardHistory"))
    except OSError:
        pass
    for root, path, name in targets:
        try:
            _set_dword(root, path, name, val)
        except Exception as exc:
            log(f"clipboard reg {path}\\{name} {exc}")
    log(f"clipboard registry lock={lock_on} value={val}")


def apply_status(data: dict) -> None:
    mode = data.get("mode") or "blacklist"
    apply_hosts(bool(data.get("enabled")), data.get("rules") or [], mode)
    apply_browser_policy(data)
    apply_clipboard_reg(bool(data.get("disable_copy")))


def perform_upgrade(cfg: dict) -> bool:
    url = f"http://{cfg['teacher_ip']}:{int(cfg['port'])}/files/student_client.py"
    target = Path(__file__).resolve()
    try:
        req = urllib.request.Request(url, headers={"User-Agent": f"MarcussenStudent/{CLIENT_VERSION}"})
        with urllib.request.urlopen(req, timeout=20) as resp:
            raw = resp.read()
        if b"CLIENT_VERSION" not in raw or len(raw) < 200:
            log("upgrade rejected: payload too small")
            return False
        tmp = target.with_suffix(".py.new")
        tmp.write_bytes(raw)
        os.replace(tmp, target)
        log(f"upgraded client from {url}")
        try:
            subprocess.run(["schtasks", "/Run", "/TN", "Marcussen"], check=False, **_hidden_kwargs())
        except Exception:
            pass
        return True
    except Exception as exc:
        log(f"upgrade failed {exc}")
        return False


class ReloadHandler(BaseHTTPRequestHandler):
    cfg = {}

    def log_message(self, fmt, *args):
        return

    def do_GET(self):
        if self.path.startswith("/reload"):
            data = fetch_status(self.cfg)
            if data is not None:
                apply_status(data)
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"ok")
            return
        if self.path.startswith("/upgrade"):
            ok = perform_upgrade(self.cfg)
            self.send_response(200 if ok else 500)
            self.end_headers()
            self.wfile.write(b"ok" if ok else b"fail")
            return
        self.send_response(404)
        self.end_headers()


def start_reload(cfg: dict) -> None:
    ReloadHandler.cfg = cfg

    def run():
        try:
            HTTPServer(("0.0.0.0", RELOAD_PORT), ReloadHandler).serve_forever()
        except Exception as exc:
            log(f"reload server {exc}")

    threading.Thread(target=run, daemon=True).start()


def daemon_loop() -> None:
    start_reload(load_config())
    while True:
        cfg = load_config()
        ReloadHandler.cfg = cfg
        data = fetch_status(cfg)
        if data is not None:
            apply_status(data)
            if data.get("disable_copy"):
                try:
                    subprocess.run(["schtasks", "/Run", "/TN", "MarcussenClip"], check=False, **_hidden_kwargs())
                except Exception:
                    pass
        time.sleep(max(30, int(cfg.get("poll_seconds") or 120)))


def ui_loop() -> None:
    import tkinter as tk
    from tkinter import messagebox, simpledialog

    root = tk.Tk()
    root.title("Marcussen")
    root.geometry("420x180")
    status = tk.StringVar(value="Connecting…")
    tk.Label(root, textvariable=status, wraplength=380, justify="left").pack(padx=16, pady=16)

    def tick():
        cfg = load_config()
        url = f"http://{cfg['teacher_ip']}:{cfg['port']}/status"
        data = fetch_status(cfg)
        if data is None:
            status.set(f"Trying {url}")
        else:
            pw = data.get("unlock_password") or ""
            status.set(f"Connected as {computer_name()} / {login_name() or 'no login'}. Close with the teacher password.")
            root._unlock = pw
        root.after(4000, tick)

    def on_close():
        pw = getattr(root, "_unlock", "")
        if not pw:
            messagebox.showinfo("Marcussen", "No password has been set yet and the window cannot close.")
            return
        entered = simpledialog.askstring("Marcussen", "Unlock password:", show="*")
        if entered == pw:
            root.destroy()

    threading.Thread(target=clip_loop, daemon=True).start()
    root.protocol("WM_DELETE_WINDOW", on_close)
    root.after(200, tick)
    root.mainloop()


def empty_clipboard() -> None:
    if os.name != "nt":
        return
    try:
        import ctypes
        user32 = ctypes.windll.user32
        if user32.OpenClipboard(None):
            user32.EmptyClipboard()
            user32.CloseClipboard()
    except Exception:
        pass
    try:
        subprocess.run(
            [
                "powershell",
                "-STA",
                "-NoProfile",
                "-WindowStyle",
                "Hidden",
                "-Command",
                "Add-Type -AssemblyName System.Windows.Forms; [System.Windows.Forms.Clipboard]::Clear()",
            ],
            check=False,
            **_hidden_kwargs(),
        )
    except Exception:
        pass


def clip_loop() -> None:
    """User-session helper: registry, empty clipboard, steal Ctrl+C/V/X."""
    log("clipboard helper started")
    if os.name != "nt":
        while True:
            time.sleep(10)
        return

    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    MOD_CONTROL, MOD_SHIFT, MOD_NOREPEAT = 0x0002, 0x0004, 0x4000
    VK_C, VK_V, VK_X, VK_INSERT = 0x43, 0x56, 0x58, 0x2D
    WM_HOTKEY = 0x0312
    PM_REMOVE = 1
    locked = False
    last_poll = 0.0

    def grab():
        flags = MOD_CONTROL | MOD_NOREPEAT
        user32.RegisterHotKey(None, 1, flags, VK_C)
        user32.RegisterHotKey(None, 2, flags, VK_V)
        user32.RegisterHotKey(None, 3, flags, VK_X)
        user32.RegisterHotKey(None, 4, flags, VK_INSERT)
        user32.RegisterHotKey(None, 5, MOD_SHIFT | MOD_NOREPEAT, VK_INSERT)
        log("Ctrl+C/V/X hotkeys reserved")

    def release():
        for i in range(1, 6):
            user32.UnregisterHotKey(None, i)
        log("Ctrl+C/V/X hotkeys released")

    msg = wintypes.MSG()
    try:
        while True:
            now = time.time()
            if now - last_poll > 1.5:
                last_poll = now
                data = fetch_status(load_config())
                want = bool(data and data.get("disable_copy"))
                if want != locked:
                    apply_clipboard_reg(want)
                    if want:
                        grab()
                    else:
                        release()
                    locked = want
                    log(f"clipboard lock {want}")
                if locked:
                    empty_clipboard()
            if user32.PeekMessageW(ctypes.byref(msg), 0, 0, 0, PM_REMOVE):
                if locked and msg.message == WM_HOTKEY:
                    empty_clipboard()
                    continue
                user32.TranslateMessage(ctypes.byref(msg))
                user32.DispatchMessageW(ctypes.byref(msg))
            else:
                time.sleep(0.05)
    except Exception as exc:
        log(f"clip loop {exc}")
        try:
            release()
        except Exception:
            pass
        while True:
            time.sleep(10)


def main() -> None:
    if "--clip" in sys.argv:
        clip_loop()
        return
    if "--daemon" in sys.argv or os.environ.get("MARCUSSEN_DAEMON") == "1":
        daemon_loop()
        return
    ui_loop()


if __name__ == "__main__":
    main()
