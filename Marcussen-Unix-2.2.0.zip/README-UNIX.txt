Marcussen student client — macOS and Linux
==========================================

The teacher console is the same Python app on Windows, macOS, and Linux.
Student enforcement is per OS:

  Windows  hosts file + Chrome/Edge/Opera/Firefox policy + scheduled tasks
  macOS    /etc/hosts + Chrome/Edge/Opera policy JSON + Firefox policies.json
           + LaunchDaemon io.marcussen.client
  Linux    /etc/hosts + /etc/opt/chrome|edge|chromium policy JSON
           + Firefox policies.json + systemd marcussen.service

Install student (Mac/Linux)
---------------------------
1. Install Python 3 with Tk if you also want the optional status window.
2. Copy this folder to the machine.
3. sudo ./install_unix.sh 10.0.18.70 8080

Replace the IP and port with the teacher console address.

Teacher console (Mac/Linux)
---------------------------
  python3 teacher_admin.py

Windows public student installer remains:
  https://github.com/kgmarcussen/Marcussen/raw/main/Marcussen-Student-Setup.exe

Limits
------
- Policy JSON needs a full browser quit.
- Portable browsers in a home folder may ignore machine policy; hosts still
  blocks whole domains.
- Ctrl+C/V lock is Windows-only.
- Root/admin is required to write /etc/hosts and policy directories.
